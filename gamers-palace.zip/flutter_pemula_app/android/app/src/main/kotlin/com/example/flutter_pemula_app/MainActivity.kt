package com.example.flutter_pemula_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
