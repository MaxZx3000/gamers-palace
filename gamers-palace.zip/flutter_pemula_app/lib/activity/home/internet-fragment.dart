import 'package:flutter/cupertino.dart';

abstract class InternetFragment extends StatefulWidget {
  void changeIndexPage(int index);
}
