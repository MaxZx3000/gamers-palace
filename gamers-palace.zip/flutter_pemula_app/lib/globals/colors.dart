const CUSTOM_COLORS = {
  'darkBlue': 0xFF000272,
  'darkViolet': 0xFF341677,
  'darkRed': 0xFFa32f80,
  'red': 0xFFff6363,
  'darkGray': 0xFF4d4d4d
};
